"""
File: SperryMaurieFinalProject.py
Author: Maurie Sperry
Description:  This presents page 1 of a 2-page app that simulates ordering
              a pizza online.  This page gathers the details of the pizza
              to be ordered.  The second page, reached by clicking on the
              "Checkout" button, collects the name and phone# of the
              customer, as well as the payment information.
"""

from tkinter import *


# Global variables:

Pizza12Selected = False         # These 3 variables are used to make sure
Pizza14Selected = False         # the client selects the size of pizza.
Pizza16Selected = False

ThinCrustSelected = False       # These 2 variables are used to make sure
ThickCrustSelected = False      # the client selects a type of crust.

ExtraCheeseSelected = False     # This group of variables are used to record
MushroomSelected = False        # the pizza toppings the customer has chosen.
GreenPepperSelected = False
PepperoniSelected = False
SausageHotSelected = False
SausageMildSelected = False

# Here are a couple of notes about the pizza toppings.
ToppingsLine1 = "Tomato Sauce and Mozzarella Cheese are standard and free."
ToppingsLine2 = 'Each additional topping is 0.25 on a 12", ' \
                '0.35 on a 14", and 0.45 on a 16".'

TotalCost = 0.00    # The total cost of the pizza the customer has ordered.


Width = 800         # I had intended to use these as arguments for the
Height = 800        # window.geometry method, but that didn't work.
                    # However, I used Width in the page headings definitions.

# My attempt to center the page headings:
Line1 = "Mo Betta Pizza"
Line1X = ((Width - len(Line1)) / 2) - 50
Line2 = "123 Main St, Capital City"
Line2X = ((Width - len(Line2)) / 2) - 60
Line3 = "Phone: 123 456-7890"
Line3X = ((Width - len(Line3)) / 2) - 50

Margin1 = 50        # I used these as standard margin indentations for the
Margin2 = 80        # text in this page.
Margin3 = 230
Margin4 = 250


# Command processors:

# Get Pizza Size:
def Pizza12():
    global Pizza12Selected
    if Pizza12Btn['bg']!='#ccccff':     # Not Highlighted
        ResetPizzaSize()
        Pizza12Btn['bg']='#ccccff'      # Highlight
        Pizza12Selected = True
        CalcTotalCost()

def Pizza14():
    global Pizza14Selected
    if Pizza14Btn['bg']!='#ccccff':     # Not Highlighted
        ResetPizzaSize()
        Pizza14Btn['bg']='#ccccff'      # Highlight
        Pizza14Selected = True
        CalcTotalCost()

def Pizza16():
    global Pizza16Selected
    if Pizza16Btn['bg']!='#ccccff':     # Not Highlighted
        ResetPizzaSize()
        Pizza16Btn['bg']='#ccccff'      # Highlight
        Pizza16Selected = True
        CalcTotalCost()

def ResetPizzaSize():
    global Pizza12Selected
    global Pizza14Selected
    global Pizza16Selected

    Pizza12Btn['bg']='#f0f0f0'          # Default color
    Pizza14Btn['bg']='#f0f0f0'
    Pizza16Btn['bg']='#f0f0f0'
    Pizza12Selected = False
    Pizza14Selected = False
    Pizza16Selected = False


# Get Type of Crust:
def ThinCrust():
    global ThinCrustSelected
    
    if ThinCrustBtn['bg']!='#ccccff':     # Not Highlighted
        ResetCrust()
        ThinCrustBtn['bg']='#ccccff'
        ThinCrustSelected = True
        CalcTotalCost()

def ThickCrust():
    global ThickCrustSelected

    if ThickCrustBtn['bg']!='#ccccff':     # Not Highlighted
        ResetCrust()
        ThickCrustBtn['bg']='#ccccff'
        ThickCrustSelected = True
        CalcTotalCost()

def ResetCrust():
    global ThinCrustSelected
    global ThickCrustSelected
    
    ThinCrustBtn['bg']='#f0f0f0'            # Not Highlighted
    ThickCrustBtn['bg']='#f0f0f0'
    ThinCrustSelected = False
    ThickCrustSelected = False

# Get additional toppings:
def ExtraCheese():
    global ExtraCheeseSelected

    if ExtraCheeseBtn['bg']=='#ccccff':            # Highlighted
        ExtraCheeseBtn['bg']='#f0f0f0'       # Not Highlighted
        ExtraCheeseSelected = False
        CalcTotalCost()
    else:
        ExtraCheeseBtn['bg']='#ccccff'      # Highlighted
        ExtraCheeseSelected = True
        CalcTotalCost()
        
def Mushroom():
    global MushroomSelected

    if MushroomBtn['bg']=='#ccccff':               # Highlighted
        MushroomBtn['bg']='#f0f0f0'          # Not Highlighted
        MushroomSelected = False
        CalcTotalCost()
    else:
        MushroomBtn['bg']='#ccccff'         # Highlighted
        MushroomSelected = True
        CalcTotalCost()
        
def GreenPepper():
    global GreenPepperSelected

    if GreenPepperBtn['bg']=='#ccccff':            # Highlighted
        GreenPepperBtn['bg']='#f0f0f0'       # Not Highlighted
        GreenPepperSelected = False
        CalcTotalCost()
    else:
        GreenPepperBtn['bg']='#ccccff'      # Highlighted
        GreenPepperSelected = True
        CalcTotalCost()
        
def Pepperoni():
    global PepperoniSelected

    if PepperoniBtn['bg']=='#ccccff':              # Highlighted
        PepperoniBtn['bg']='#f0f0f0'         # Not Highlighted
        PepperoniSelected = False
        CalcTotalCost()
    else:
        PepperoniBtn['bg']='#ccccff'        # Highlighted
        PepperoniSelected = True
        CalcTotalCost()
        
def SausageHot():
    global SausageHotSelected

    if SausageHotBtn['bg']=='#ccccff':             # Highlighted
        SausageHotBtn['bg']='#f0f0f0'        # Not Highlighted
        SausageHotSelected = False
        CalcTotalCost()
    else:
        SausageHotBtn['bg']='#ccccff'       # Highlighted
        SausageHotSelected = True
        CalcTotalCost()
        
def SausageMild():
    global SausageMildSelected
    
    if SausageMildBtn['bg']=='#ccccff':            # Highlighted
        SausageMildBtn['bg']='#f0f0f0'       # Not Highlighted
        SausageMildSelected = False
        CalcTotalCost()
    else:
        SausageMildBtn['bg']='#ccccff'      # Highlighted
        SausageMildSelected = True
        CalcTotalCost()


# Calculate the cost of the pizza.  This will be called whenever changes are made.
def CalcTotalCost():
    global Pizza12Selected
    global Pizza14Selected
    global Pizza16Selected

    global ThinCrustSelected
    global ThickCrustSelected

    if     (Pizza12Selected == False
        and Pizza14Selected == False
        and Pizza16Selected == False):
        message = "Please choose a Pizza Size."
        SendMessage(message)

    elif (ThinCrustSelected == False and ThickCrustSelected == False):
        message = "Please select a Type of Crust."
        SendMessage(message)

    else:
        message = ""
        SendMessage(message)
        ToppingsCount = CountToppings()

        if Pizza12Selected == True:
            TotalCost = 10 + (ToppingsCount * 0.25)

        if Pizza14Selected == True:
            TotalCost = 12 + (ToppingsCount * 0.35)

        if Pizza16Selected == True:
            TotalCost = 14 + (ToppingsCount * 0.45)
            
        TotalCostEntry.delete(0, "end")
        TotalCostEntry.insert(0, "$" + f'{TotalCost:.2f}')


# Toppings are the same price per Pizza Size.
def CountToppings():
    global ExtraCheeseSelected
    global MushroomSelected
    global GreenPepperSelected
    global PepperoniSelected
    global SausageHotSelected
    global SausageMildSelected
    
    ToppingsCount = 0
    
    if ExtraCheeseSelected == True:
        ToppingsCount += 1
        
    if MushroomSelected == True:
        ToppingsCount += 1
        
    if GreenPepperSelected == True:
        ToppingsCount += 1
        
    if PepperoniSelected == True:
        ToppingsCount += 1
        
    if SausageHotSelected == True:
        ToppingsCount += 1
        
    if SausageMildSelected == True:
        ToppingsCount += 1
        
    return(ToppingsCount)


def SendMessage(message):
    message = message
    MessageEntry.delete(0, "end")
    MessageEntry.insert(0, message)


# Go to the second page to mimic capturing name and payment information.
def CheckOut():
    window.destroy()
    import SperryMaurieFinalProjectB


def Cancel():
    window.destroy()


# Window variables:
        
window=Tk()

window.title('SDEV140 Final Project, Maurie Sperry')
window.geometry("800x800+10+10")


# Widget definitions:

lbl=Label(window, text=Line1, fg='red', font=("Helvetica", 16))
lbl.place(x=Line1X, y=20)

lbl=Label(window, text=Line2, fg='green', font=("Helvetica", 12))
lbl.place(x=Line2X, y=45)

lbl=Label(window, text=Line3, fg='red', font=("Helvetica", 12))
lbl.place(x=Line3X, y=65)

lbl=Label(window, text="Build your pizza:", fg='red', font=("Helvetica", 12))
lbl.place(x=Margin1, y=120)

lbl=Label(window, text="Pizza size:", fg='green', font=("Helvetica", 12))
lbl.place(x=Margin2, y=160)

Pizza12Btn=Button(window, text='12"', fg='blue', command = Pizza12)
Pizza12Btn.place(x=(Margin2 + 150), y=160)

Pizza14Btn=Button(window, text='14"', fg='blue', command = Pizza14)
Pizza14Btn.place(x=(Margin2 + 220), y=160)

Pizza16Btn=Button(window, text='16"', fg='blue', command = Pizza16)
Pizza16Btn.place(x=(Margin2 + 290), y=160)

lbl=Label(window, text="Base price:", fg='green', font=("Helvetica", 12))
lbl.place(x=Margin2, y=200)

lbl=Label(window, text="$10", fg='blue', font=("Helvetica", 10))
lbl.place(x=(Margin2 + 150), y=200)

lbl=Label(window, text="$12", fg='blue', font=("Helvetica", 10))
lbl.place(x=(Margin2 + 220), y=200)

lbl=Label(window, text="$14", fg='blue', font=("Helvetica", 10))
lbl.place(x=(Margin2 + 290), y=200)

lbl=Label(window, text="Type of crust:", fg='green', font=("Helvetica", 12))
lbl.place(x=Margin2, y=240)

ThinCrustBtn=Button(window, text="Thin & crispy", fg='blue', command = ThinCrust)
ThinCrustBtn.place(x=Margin3, y=240)

ThickCrustBtn=Button(window, text="Thick & chewey", fg='blue', command = ThickCrust)
ThickCrustBtn.place(x=(Margin3 + 100), y=240)

lbl=Label(window, text="Toppings:", fg='green', font=("Helvetica", 12))
lbl.place(x=Margin2, y=280)

lbl=Label(window, text=ToppingsLine1, fg='blue', font=("Helvetica", 10))
lbl.place(x=Margin3, y=280)

lbl=Label(window, text=ToppingsLine2, fg='blue', font=("Helvetica", 10))
lbl.place(x=Margin3, y=300)

lbl=Label(window, text="Choose additional toppings from the following:",
          fg='blue', font=("Helvetica", 10))
lbl.place(x=Margin3, y=320)

ExtraCheeseBtn=Button(window, text="Extra Cheese", fg='blue', command=ExtraCheese)
ExtraCheeseBtn.place(x=Margin4, y=350)

MushroomBtn=Button(window, text="Mushroom", fg='blue', command=Mushroom)
MushroomBtn.place(x=Margin4, y=390)

GreenPepperBtn=Button(window, text="Green Pepper", fg='blue', command=GreenPepper)
GreenPepperBtn.place(x=Margin4, y=430)

PepperoniBtn=Button(window, text="Pepperoni", fg='blue', command=Pepperoni)
PepperoniBtn.place(x=Margin4, y=470)

SausageHotBtn=Button(window, text="Sausage, hot", fg='blue', command=SausageHot)
SausageHotBtn.place(x=Margin4, y=510)

SausageMildBtn=Button(window, text="Sausage, mild", fg='blue', command=SausageMild)
SausageMildBtn.place(x=Margin4, y=550)

lbl=Label(window, text="Total Cost:", fg='red', font=("Helvetica", 12))
lbl.place(x=Margin2, y=620)

TotalCostEntry = Entry(window, bg='#f0f0f0', fg='green', justify='right',
            width='8', font=("Helvetica", 10))
TotalCostEntry.place(x=Margin2 + 100, y=620)

MessageEntry = Entry(window, bg='#f0f0f0', fg='red', justify='left',
            width='50', font=("Helvetica", 10))
MessageEntry.place(x=Margin4 + 50, y=620)

CheckOutBtn=Button(window, text="Check out", fg='Green', command=CheckOut)
CheckOutBtn.place(x=700, y=690)

CancelBtn=Button(window, text="Cancel", fg='red', command=Cancel)
CancelBtn.place(x=700, y=730)


# Continuously look for events:
window.mainloop()
