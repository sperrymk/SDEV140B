"""
File: SperryMaurieFinalProject.py
Author: Maurie Sperry
Description:  This presents page 2 of a 2-page app that simulates ordering
              a pizza online.  This page collects the name and phone# of the
              customer, as well as the payment information.
"""

from tkinter import *


# Global variables:

Width = 800         # I had intended to use these as arguments for the
Height = 800        # window.geometry method, but that didn't work.
                    # However, I used Width in the page headings definitions.

# My attempt to center the page headings:
Line1 = "Mo Betta Pizza"
Line1X = ((Width - len(Line1)) / 2) - 50
Line2 = "123 Main St, Capital City"
Line2X = ((Width - len(Line2)) / 2) - 60
Line3 = "Phone: 123 456-7890"
Line3X = ((Width - len(Line3)) / 2) - 50

# This is a note to the customer:
PizzaLine = "Your pizza will be ready about 30 minutes after submitting order."

TotalCost = 0.00    # The total cost of the pizza the customer has ordered.

Margin1 = 50        # I used these as standard margin indentations for the
Margin2 = 80        # text in this page.
Margin3 = 230
Margin4 = 250


# Command processors:

# Nothing is actually submitted, but it is supposed to look like it:
def SubmitOrder():
    # Collect the entries the customer made:
    
    Name = NameEntry.get()
    PhoneNumber = PhoneEntry.get()
    CardNumber = CardEntry.get()

    if Name == " ":
        message = "Please enter your name."
        SendMessage(message)
    elif PhoneNumber == " ":
        message = "Please enter your phone#."
        SendMessage(message)
    elif CardNumber == " ":
        message = "Please enter your credit or debit card number."
        SendMessage(message)
    else:
        window.destroy()


def Cancel():
    window.destroy()


def SendMessage(message):
    message = message
    MessageEntry.delete(0, "end")
    MessageEntry.insert(0, message)


# Set the screen input fields to spaces:
def InitializeScreenVariables():
    NameEntry.delete(0, "end")
    NameEntry.insert(0, " ")
    PhoneEntry.delete(0, "end")
    PhoneEntry.insert(0, " ")
    CardEntry.delete(0, "end")
    CardEntry.insert(0, " ")


# Window definitions:
        
window=Tk()

window.title('SDEV140 Final Project Page 2, Maurie Sperry')
window.geometry("800x800+10+10")


# Widget definitions:

lbl=Label(window, text=Line1, fg='red', font=("Helvetica", 16))
lbl.place(x=Line1X, y=20)

lbl=Label(window, text=Line2, fg='green', font=("Helvetica", 12))
lbl.place(x=Line2X, y=45)

lbl=Label(window, text=Line3, fg='red', font=("Helvetica", 12))
lbl.place(x=Line3X, y=65)

lbl=Label(window, text="Your name:", fg='black', font=("Helvetica", 10))
lbl.place(x=70, y = 200)

NameEntry = Entry(window, fg='black', justify='left',
            width='40', font=("Helvetica", 10))
NameEntry.place(x=150, y=200)

lbl=Label(window, text="Your phone#:", fg='black', font=("Helvetica", 10))
lbl.place(x=460, y = 200)

PhoneEntry = Entry(window, fg='black', justify='left',
            width='20', font=("Helvetica", 10))
PhoneEntry.place(x=550, y=200)

v0=IntVar()
v0.set(1)
r1=Radiobutton(window, text="Credit", variable=v0,value=1)
r2=Radiobutton(window, text="Debit", variable=v0,value=2)
r1.place(x=200,y=250)
r2.place(x=260, y=250)

lbl=Label(window, text="Card#:", fg='black', font=("Helvetica", 10))
lbl.place(x=360, y = 250)

CardEntry = Entry(window, fg='black', justify='left',
            width='30', font=("Helvetica", 10))
CardEntry.place(x=420, y=250)

lbl=Label(window, text=PizzaLine, fg='red', font=("Helvetica", 14))
lbl.place(x=120, y = 300)

SubmitOrderBtn=Button(window, text="Submit order", fg='Green', command=SubmitOrder)
SubmitOrderBtn.place(x=600, y=490)

CancelBtn=Button(window, text="Cancel", fg='red', command=Cancel)
CancelBtn.place(x=600, y=530)

MessageEntry = Entry(window, bg='#f0f0f0', fg='red', justify='left',
            width='50', font=("Helvetica", 10))
MessageEntry.place(x=Margin4 + 50, y=620)


InitializeScreenVariables()

# Continuously look for events:
window.mainloop()
